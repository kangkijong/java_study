package chapter21_mini_project_TJG404.model;

public interface BookVo {

}
