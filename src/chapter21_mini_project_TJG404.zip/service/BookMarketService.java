package chapter21_mini_project_TJG404.service;

import java.util.List;

public interface BookMarketService {
	void menuMemberAdd();
	void menuMemberInfo();
	void menuCartList();
	void menuCartClear();
	void menuCartAddItem();
	void menuCartRemoveItem();
	void menuCartBill();
	void exit();
}
