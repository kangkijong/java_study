package chapter21_mini_project_TJG404.repository;

import java.util.List;

import chapter21_mini_project.model.MemberVo;
import db.DBConn;

public class CartRepositoryImpl extends DBConn 
				implements BookMarketRepositoryInterface<MemberVo>{
	public int insert(MemberVo entity) {}
	public List<MemberVo> findAll(){}
	public MemberVo find(String id) {}
	public int update(MemberVo entity) {}
	public int remove(String id) {}
	public int removeAll() {}
	public void close() {}
}
